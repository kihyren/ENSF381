import React from 'react';
import Home from './Home'
import About from './About'
import Contact from   './Contact'
import EngineeringTopics from './EngineeringTopics'

function App() {
  // Embed JavaScript Expressions in JSX
  const d = new Date()
  var currentYear = d.getFullYear()

  // Using a Conditional Statement in JSX
  var isLoggedIn = true
  var logIn = isLoggedIn ? "Welcome Back!" : "Please log in."

  return (    
    <div>
      <h1>ENSF-381: Full Stack Web Development</h1>
        <p>React Components</p>
        <p>{currentYear}</p>
        <p>{logIn}</p>

      <Home page="Home"/>
      <About page="About Us"/>
      <Contact page="Contact Us"/>
      <EngineeringTopics/>
    </div>
  );
}

export default App;
