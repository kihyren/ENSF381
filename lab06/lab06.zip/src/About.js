import React from 'react'

function About (props) {
    return (
        <div>
            <h1>Welcome to the {props.page} page!</h1>
              <p>We are passionate about delivering quality experiences.</p>
        </div>
    )
}

export default About;